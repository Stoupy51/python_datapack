
import os
os.system("py -m twine upload --verbose -r python_datapack dist/*")

