
# Imports
from .simpledrawer import simpledrawer

def main(config: dict):

	# Compatibility with SimpleDrawer's compacting drawer
	simpledrawer(config)

