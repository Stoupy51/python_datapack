
import os
os.system("py -m pip install --upgrade pip setuptools build twine")

