
import os
os.system("py -m build")

