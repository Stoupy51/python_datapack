
# 📦 Package Link
[https://pypi.org/project/python-datapack/](https://pypi.org/project/python-datapack/)

# 🐍 Python Datapack
Here is a template to a GitHub repository using this Python package: 📝
[https://github.com/Stoupy51/PythonDatapackTemplate](https://github.com/Stoupy51/PythonDatapackTemplate)

Here is an advanced example using this Python package: ⚡
[https://github.com/Stoupy51/SimplEnergy](https://github.com/Stoupy51/SimplEnergy)

