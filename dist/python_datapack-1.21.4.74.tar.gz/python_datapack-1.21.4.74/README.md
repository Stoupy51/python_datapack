
# 📦 Package Link
[https://pypi.org/project/python-datapack/](https://pypi.org/project/python-datapack/)

# 🐍 Python Datapack
Here is a template to a GitHub repository using this Python package: 📝
[https://github.com/Stoupy51/PythonDatapackTemplate](https://github.com/Stoupy51/PythonDatapackTemplate)

Here is an advanced example using this Python package: ⚡
[https://github.com/Stoupy51/SimplEnergy](https://github.com/Stoupy51/SimplEnergy)

## ⭐ Star History

<a href="https://star-history.com/#Stoupy51/python_datapack&Date">
 <picture>
   <source media="(prefers-color-scheme: dark)" srcset="https://api.star-history.com/svg?repos=Stoupy51/python_datapack&type=Date&theme=dark" />
   <source media="(prefers-color-scheme: light)" srcset="https://api.star-history.com/svg?repos=Stoupy51/python_datapack&type=Date" />
   <img alt="Star History Chart" src="https://api.star-history.com/svg?repos=Stoupy51/python_datapack&type=Date" />
 </picture>
</a>

