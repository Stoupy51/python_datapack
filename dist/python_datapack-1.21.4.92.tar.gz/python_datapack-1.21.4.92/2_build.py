
import os
import sys
os.system(f"{sys.executable} -m build")

