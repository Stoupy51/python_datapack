
import os
import sys

os.system(f"{sys.executable} -m pip install --upgrade pip setuptools build twine packaging")

