
# 📖 Furnace NBT Recipes
Figure out how to use it yourself!

